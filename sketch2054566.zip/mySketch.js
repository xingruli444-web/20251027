function setup() {
	createCanvas(900, 900);
	rectMode(CENTER);
	background(255);
	stroke(0);
	for (let i = 0; i < 1000; i++) {
		let x = randomGaussian(0.5, 0.13) * width;
		let y = randomGaussian(0.5, 0.13) * height;
		backInTheDay(x, y);
	}

	for (let i = 0; i < 100; i++) {
		let x = randomGaussian(0.5, 0.13) * width;
		let y = randomGaussian(0.5, 0.13) * height;
		let s = random(width) * random(random());
		strokeWeight(random(random()));
		if(random()<0.5){
			square(x, y, s);
		}else{
			circle(x, y, s);

		}
	}
}

function draw() {

}

function backInTheDay(x, y) {
	let c = int(random(10, 50));
	let scl = 0.005;
	let rnd = int(random(3));
	strokeWeight(random(random()));
	noFill();
	beginShape();
	if (rnd == 0) {
		for (let i = 0; i < c; i++) {
			let n = noise(x * scl, y * scl, i * 0.00001);
			let angle = int(n * 10) * (TAU / 4);
			vertex(x, y);
			x += cos(angle) * 8;
			y += sin(angle) * 8;
		}
		endShape();
	}
	else if (rnd == 1) {
		for (let i = 0; i < c; i++) {
			let n = noise(x * scl, y * scl, i * 0.00001);
			let angle = 10 * n;
			vertex(x, y);
			x += cos(angle) * 8;
			y += sin(angle) * 8;
		}
		endShape();
	}

	else if (rnd == 2) {
		for (let i = 0; i < c; i++) {
			let n = noise(x * scl, y * scl, i * 0.001);
			let angle = int(n * 15) * (TAU / 4);
			strokeWeight(random(random()));
			circle(x, y, random(random(10)));
			x += cos(angle) * 8;
			y += sin(angle) * 8;
		}
	}

	else if (rnd == 3) {
		for (let i = 0; i < c; i++) {
			let n = noise(x * scl, y * scl, i * 0.001);
			let angle = 15 * n;
			strokeWeight(random(random()));
			circle(x, y, random(random(10)));
			x += cos(angle) * 8;
			y += sin(angle) * 8;
		}
	}
}